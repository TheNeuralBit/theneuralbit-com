#include "pred-prey.h"

#define SIZE 100
#define REPRO_LIMIT 2
#define LINE 50
#define TOK  10

int numOrgs;
organism* orgs;
int len;
FILE* out;
int map[SIZE][SIZE];
int* pops;
int* food;

int main(){
  time_t seconds = time(NULL);
  srandom(seconds);

  printf("How many organisms? ");
  scanf("%d", &numOrgs);

  orgs = (organism*)calloc(numOrgs, sizeof(organism));
  
  int i;
  for( i = 0; i < numOrgs; i++ ){
    orgs[i].name = (char*)calloc(50, sizeof(char));

    printf("\nOrganism %d:\n", i);
    printf("Name? ");
    scanf("%s", orgs[i].name);
    printf("Carnivore fitness? ");
    scanf("%lf", &(orgs[i].carn_fit));
    printf("Herbivore fitness? ");
    scanf("%lf", &(orgs[i].herb_fit));
    
  }
  printf("How many iterations should the simulaton have? ");
  scanf("%d", &len);

  char* outFile = "out";
  out = fopen(outFile, "w");

  runSimulation();

  out = fopen("plotFile", "w");
  fprintf(out, "plot ");

  for( i = 0; i < numOrgs; i++){
    if(i > 0){fprintf(out, ",");}
    fprintf(out, "\"%s\" using 1:%d title \"%s\" with lines", outFile, i + 2, orgs[i].name);
  }
  fprintf(out, "\nset xlabel \"Iterations\"\n");
  fprintf(out, "set ylabel \"Population\"\n");
  fprintf(out, "set term png medium\n");
  fprintf(out, "set out \"plot.png\"\n");
  fprintf(out, "replot\n");
  fprintf(out, "set out\n");
  fclose(out);
}

void runSimulation(){
  pops = (int*)calloc(numOrgs, sizeof(int)); // store the population of each species
  food = (int*)calloc(numOrgs, sizeof(int)); // store the amount of food each species has

  // initialize map
  int x;
  int y;
  for( x = 0; x < SIZE; x++ ){
    for( y = 0; y < SIZE; y++ ){
      map[x][y] = myRand() * numOrgs;
      pops[map[x][y]]++;
    }
  }

  int iter;
  for( iter = 0; iter < len; iter++ ){
    writeToFile(iter);

    tryEat();  
    starve();
    reproduce();
  }
}

void tryEat(){
  int x;
  int y;
  for( x = 0; x < SIZE; x++){
    for( y = 0 ; y < SIZE; y++){
      int me = map[x][y];
      if( me == -1 ){continue;}
      
      // first, try to eat the organisms around you
      int them;
      bool eaten = false;
      // x-1, y
      them = map[x - 1 > 0 ? x - 1 : SIZE - 1][y];
      if( canEat(me, them) ){ 
	map[x - 1 > 0 ? x - 1 : SIZE - 1][y] = -1;
	food[me]++;
	pops[them]--;
        eaten = true;
      }
      // x+1, y
      them = map[(x + 1) % SIZE][y];
      if( canEat(me, them) && !eaten){ 
	map[(x + 1) % SIZE][y] = -1;
	food[me]++;
	pops[them]--;
        eaten = true;
      }
      // x, y-1
      them = map[x][y - 1 > 0 ? y - 1: SIZE - 1];
      if( canEat(me, them) && !eaten){ 
 	map[x][y - 1 > 0 ? y - 1: SIZE - 1] = -1;
        food[me]++;
	pops[them]--;
        eaten = true;
      }
      // x, y+1
      them = map[x][(y + 1) % SIZE];
      if( canEat(me, them) && !eaten){ 
	map[x][(y + 1) % SIZE] = -1;
	food[me]++;
	pops[them]--;
        eaten = true;
      }

      // if you fail, try to eat plants
      int i;
      //for(i = 0; i < 4; i++){
        if( myRand() < orgs[me].herb_fit && !eaten){
          food[me]++;
        }
      //}
    }
  }
}

// returns true if me is not the same species as them
// and if me has a greater carn_fit than them
bool canEat(int me, int them){
  return them != -1 && me != them && myRand() < (orgs[me].carn_fit - orgs[them].carn_fit);
}

void starve(){
  /*
  int* newPops = (int*)calloc(numOrgs, sizeof(int));
  int* newFood = (int*)calloc(numOrgs, sizeof(int));
  
  int i;
  for( i = 0; i < numOrgs; i++ ){
    newPops[i] = pops[i];
    newFood[i] = food[i];
  }
  */

  int x;
  int y;
  for( x = 0; x < SIZE; x++){
    for( y = 0 ; y < SIZE; y++ ){
      int me = map[x][y];
      if( me == -1 ){continue;}
      // if it dies decrement population and remove from map
      if(die(me)){
        pops[me]--;
	map[x][y] = -1;
      }
      // if it doesnt die, it uses up the food supply
      else{
        food[me]--;
      }
    }
  }
  /*
  free(pops);
  free(food);
  pops = newPops;
  food = newFood;
  */
}


bool die(int me){
  return  myRand()*pops[me] > food[me];
}

void reproduce(){
  int x;
  int y;
  for( x = 0; x < SIZE; x++){
    for( y = 0 ; y < SIZE; y++){
      if( map[x][y] != -1 ){continue;}
      
      int* numSurr = (int*)calloc(numOrgs + 1, sizeof(int));
      int xMin = x - 1 > 0 ? x - 1 : SIZE - 1;
      int xPlus = (x + 1) % SIZE;
      int yMin = y - 1 > 0 ? y - 1: SIZE - 1;
      int yPlus = (y + 1) % SIZE;

      numSurr[map[xMin][yMin] + 1]++;
      numSurr[map[xMin][y] + 1]++;
      numSurr[map[xMin][yPlus] + 1]++;
      numSurr[map[x][yMin] + 1]++;
      numSurr[map[x][yPlus] + 1]++;
      numSurr[map[xPlus][yMin] + 1]++;
      numSurr[map[xPlus][y] + 1]++;
      numSurr[map[xPlus][yPlus] + 1]++;

      int maxSpecies = 0;
      int max = 0;
      int i;
      for( i = 1; i < numOrgs + 1; i++){
        if(numSurr[i] > max){ 
	  max = numSurr[i];
	  maxSpecies = i;
	}
      }


      if(max >= REPRO_LIMIT){
        map[x][y] = --maxSpecies;
        pops[maxSpecies]++;
      }

      free(numSurr);
    }
  }
}

void writeToFile(int iter){
    fprintf(out, "%d ", iter);
    int i;
    for( i = 0; i < numOrgs; i++ ){
      fprintf(out, "%d ", pops[i]);
    }
    fprintf(out, "\n");
}

void printPops(){
  printf("Pops: ");
  int x;
  for( x = 0; x < numOrgs; x ++){
    printf("%d: %d ", x, pops[x]);
  }
  printf("\n"); 
}

void printFood(){
  printf("Food: ");
  int x;
  for( x = 0; x < numOrgs; x ++){
    printf("%d: %d ", x, food[x]);
  }
  printf("\n"); 
}

void printMap(){
  printf("\n\nMap:\n");
  int x;
  int y;
  for( x = 0; x < SIZE; x++ ){
    for( y = 0; y < SIZE; y++ ){
      printf("%d ", map[x][y]);
    }
    printf("\n");
  }
}
  
//return a random number between 0 and 1
double myRand(){
  return ((double)random())/RAND_MAX;
}
