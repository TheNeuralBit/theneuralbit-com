#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

typedef struct organism{
  char* name;
  double carn_fit;
  double herb_fit;
} organism;

void runSimulation();
void tryEat();
bool canEat(int, int);
void starve();
bool die(int);
void reproduce();
void writeToFile(int);
void printPops();
void printFood();
void printMap();
double myRand();
