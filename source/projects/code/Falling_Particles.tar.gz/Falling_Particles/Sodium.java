import java.awt.Color;
import java.util.Random;


/**
 * TODO Put here a description of what this class does.
 *
 * @author Michael Hein.
 *         Created Oct 29, 2007.
 */
public class Sodium extends Solid {
	/**
	 * Constructor.
	 *
	 * @param X
	 * @param Y
	 * @param Grid
	 */
	public Sodium(int X, int Y, Substance[][] Grid)
	{
		super(X,Y,Grid);
		Random rand = new Random();
		this.density = 8;
		this.flammability = 1;
		int k = rand.nextInt(25)+210;
		this.color = new Color(k,k,k+rand.nextInt(10));
	}
	public String toString()
	{
		return "Sodium "+this.density;
	}
	public void burn()
	{
		Random rand = new Random();
		if(rand.nextInt(7)-1 == 0)
		{
			Fire f1 = new Fire(this.x, this.y, this.grid);
			f1.disableExtinguishable();
			if(this.x != 0)
			{
				Fire f2 = new Fire(this.x-1, this.y, this.grid);
				f2.disableExtinguishable();
			}
			if(this.x != this.grid.length-1)
			{
				Fire f3 = new Fire(this.x+1, this.y, this.grid);
				f3.disableExtinguishable();
			}
			if(this.y != this.grid[0].length-1)
			{
				Fire f4 = new Fire(this.x, this.y+1, this.grid);
				f4.disableExtinguishable();
			}
		}
	}
}
