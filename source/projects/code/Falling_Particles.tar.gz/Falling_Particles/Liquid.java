import java.util.Random;


/**
 * Liquid - will settle through heavier liquids.
 *
 * @author Michael Hein.
 *         Created Oct 18, 2007.
 */
public class Liquid extends Substance {
	private int dir = -1;
	/**
	 * Constructor.
	 *
	 * @param X
	 * @param Y
	 * @param Grid
	 */
	public Liquid(int X, int Y, Substance[][] Grid)
	{
		super(X,Y,Grid);
		Random rand = new Random();
		if(rand.nextInt(2) == 0)this.dir = 1;
		else this.dir=-1;
	}
	/**
	 * Constructor.
	 *
	 */
	public Liquid()
	{
		super();
	}
	@Override
	public void timestepAct()
	{
		if(!this.exists) return;
		Random rand = new Random();
		int rander = 1;
		if(rand.nextInt(2) == 0) rander =-1;
		if(this.x == this.grid.length-1) this.dir = -1;
		if(this.x == 0)	this.dir = 1;
		
		if(!this.exists) return;
		if(this.y>=this.grid[0].length-1)
		{ // if it hit bottom, delete
			this.delete();
		}
		else if(this.grid[this.x][this.y+1] == null)
		{ // if there's nothing directly below, move there
			this.grid[this.x][this.y] = null;
			this.grid[this.x][this.y+1] = this;
			this.y+=1;
		}		
		else if(this.grid[this.x][this.y+1].getDensity() < this.density)
		{ // if below has lesser density, switch with it
			Substance hold = this.grid[this.x][this.y+1];
			hold.y = this.y;
			hold.x = this.x;
			this.grid[this.x][this.y+1] = this;
			this.grid[this.x][this.y] = hold;
			this.y+=1;
			this.x+=0;
		}
		else if(isOnGrid(this.x-rander, this.y) && this.grid[this.x-rander][this.y+1] == null)
		{ // if nothing below and to left, move there
			this.grid[this.x][this.y] = null;
			this.grid[this.x-rander][this.y+1] = this;
			this.y+=1;
			this.x-=rander;
		}
		else if(isOnGrid(this.x+rander, this.y)  && this.grid[this.x+rander][this.y+1] == null)
		{ // if nothing below and to right, move there
			this.grid[this.x][this.y] = null;
			this.grid[this.x+rander][this.y+1] = this;
			this.y+=1;
			this.x+=rander;
		}

		else if(isOnGrid(this.x+rander, this.y)  && this.grid[this.x+rander][this.y+1].getDensity() < this.density)
		{ // if below and to right has lesser density, switch
			Substance hold = this.grid[this.x+rander][this.y+1];
			hold.y = this.y;
			hold.x = this.x+rander;
			this.grid[this.x+rander][this.y+1] = this;
			this.grid[this.x][this.y] = hold;
			this.y+=1;
			this.x+=rander;
		}
		else if(isOnGrid(this.x-rander, this.y)  && this.grid[this.x-rander][this.y+1].getDensity() < this.density)
		{ // if below and to left has lesser density, switch
			Substance hold = this.grid[this.x-rander][this.y+1];
			hold.y = this.y;
			hold.x =this.x-rander;
			this.grid[this.x-rander][this.y+1] = this;
			this.grid[this.x][this.y] = hold;
			this.y+=1;
			this.x-=rander;
		}
		else
		{
			if(this.grid[this.x+this.dir][this.y] == null || this.grid[this.x+this.dir][this.y].getDensity() < this.getDensity())
			{
				Substance hold = this.grid[this.x+this.dir][this.y];
				if(hold!=null)hold.x = this.x;
				this.grid[this.x][this.y] = hold;
				this.grid[this.x+this.dir][this.y] = this;
				this.x+=this.dir;
			}
			else this.dir *=-1;	
		}
	}
	@Override
	public void burn()
	{
	}
	@Override
	public String toString()
	{
		return "Liquid at ("+this.x+", "+this.y+")";
	}
}
