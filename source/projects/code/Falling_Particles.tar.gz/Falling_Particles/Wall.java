import java.awt.Color;


/**
 * Wall - does not move.
 *
 * @author Michael Hein.
 *         Created Oct 18, 2007.
 */
public class Wall extends Substance {
	/**
	 * Constructs.
	 *
	 * @param X
	 * @param Y
	 * @param Grid
	 */
	public Wall(int X, int Y, Substance[][] Grid)
	{
		super(X,Y,Grid);
		this.density = Integer.MAX_VALUE;
		this.color = Color.gray;
	}
	@Override
	public void timestepAct()
	{
		return;
	}
	@Override
	public void burn()
	{
	}
	@Override
	public String toString()
	{
		return "Wall "+this.density;
	}
}
