
/**
 * TODO Put here a description of what this class does.
 *
 * @author Brian Hulette.
 *         Created Oct 19, 2007.
 */
public class Driver {
	/** 
	 * Very simple driver which creates a FallingSandFrame 
	 * @param args unused
	 */
	public static void main(String[] args){
		@SuppressWarnings("unused")
		FallingSandFrame frame = new FallingSandFrame(512,768);
	}
}
