import java.util.Random;


/**
 * Solid - Sinks through liquids.
 *
 * @author Michael Hein.
 *         Created Oct 18, 2007.
 */
public class Solid extends Substance {
	/**
	 * Constructor.
	 *
	 * @param X
	 * @param Y
	 * @param Grid
	 */
	public Solid(int X, int Y, Substance[][] Grid)
	{
		super(X,Y,Grid);
	}
	/**
	 * Constructor.
	 *
	 */
	public Solid()
	{
		super();
	}
	@Override
	public void timestepAct()
	{
		Random rand = new Random();
		int rander = 1;
		if(rand.nextInt(2) == 0) rander =-1;
		
		if(this.y>=this.grid[0].length-1)
		{ // if it hit bottom, delete
			this.delete();
		}
		else if(this.grid[this.x][this.y+1] == null)
		{ // if there's nothing directly below, move there
			this.grid[this.x][this.y] = null;
			this.grid[this.x][this.y+1] = this;
			this.y+=1;
		}		
		else if(this.grid[this.x][this.y+1].getDensity() < this.density && this.grid[this.x][this.y+1] instanceof Liquid)
		{ // if below has lesser density, switch with it
			Substance hold = this.grid[this.x][this.y+1];
			hold.y = this.y;
			hold.x = this.x;
			this.grid[this.x][this.y+1] = this;
			this.grid[this.x][this.y] = hold;
			this.y+=1;
			this.x+=0;
		}
		else if(isOnGrid(this.x-rander, this.y) && this.grid[this.x-rander][this.y+1] == null)
		{ // if nothing below and to left, move there
			this.grid[this.x][this.y] = null;
			this.grid[this.x-rander][this.y+1] = this;
			this.y+=1;
			this.x-=rander;
		}
		else if(isOnGrid(this.x+rander, this.y)  && this.grid[this.x+rander][this.y+1] == null)
		{ // if nothing below and to right, move there
			this.grid[this.x][this.y] = null;
			this.grid[this.x+rander][this.y+1] = this;
			this.y+=1;
			this.x+=rander;
		}

		else if(isOnGrid(this.x+rander, this.y)  && this.grid[this.x+rander][this.y+1].getDensity() < this.density && this.grid[this.x+rander][this.y+1] instanceof Liquid)
		{ // if below and to right has lesser density, switch
			Substance hold = this.grid[this.x+rander][this.y+1];
			hold.y = this.y;
			hold.x = this.x+rander;
			this.grid[this.x+rander][this.y+1] = this;
			this.grid[this.x][this.y] = hold;
			this.y+=1;
			this.x+=rander;
		}
		else if(isOnGrid(this.x-rander, this.y)  && this.grid[this.x-rander][this.y+1].getDensity() < this.density && this.grid[this.x-rander][this.y+1] instanceof Liquid)
		{ // if below and to left has lesser density, switch
			Substance hold = this.grid[this.x-rander][this.y+1];
			hold.y = this.y;
			hold.x =this.x-rander;
			this.grid[this.x-rander][this.y+1] = this;
			this.grid[this.x][this.y] = hold;
			this.y+=1;
			this.x-=rander;
		}
		else
		{
			this.grid[this.x][this.y] = this;
		}
	}
	@Override
	public void burn()
	{
	}
	@Override
	public String toString()
	{
		return "Solid at ("+this.x+", "+this.y+")";
	}
}
