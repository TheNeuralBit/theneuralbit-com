import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;


/**
 * TODO Put here a description of what this class does.
 *
 * @author Brian Hulette.
 *         Created Oct 19, 2007.
 */
public class SubstanceMover extends Thread {
	
	private Substance[][] grid;
	private FallingSandPanel FSPanel;
	private final ReentrantLock lock = new ReentrantLock();
	
	/**
	 * Initializes the SubstanceMover thread.
	 *
	 * @param grid
	 * @param FSPanel 
	 */
	public SubstanceMover(Substance[][] grid, FallingSandPanel FSPanel){
		super();
		this.grid = grid;
		this.FSPanel = FSPanel;
	}
	@Override
	public void run() {
		Random rand = new Random();
		while(true)
		{
			try
			{
				this.lock.lock();
				try
				{
					//iterate through grid, bottom to top, left to right.
					for(int y = this.grid[0].length-1; y >= 0; y--){
					{
						int m = rand.nextInt(2);
						if(m == 0)
							for(int x = 0; x <= this.grid.length-1; x++){
								if(this.grid[x][y] != null && !(this.grid[x][y] instanceof Wall))
								{
									this.grid[x][y].fixCoord(x,y);
									for(int a=1; a>=-1;--a)
									{
										for(int b=-1; b<=1;++b)
										{
											if(a!=0 || b!=0)
												if(x+a >= 0 && y+b>=0 && x+a < this.grid.length && y+b < this.grid[6].length)
													if(this.grid[x+a][y+b] !=null && x+a > 0 && y+b > 0)
														if(this.grid[x][y]!=null) this.grid[x][y].react(this.grid[x+a][y+b]);
										}
									}
									if(this.grid[x][y] != null) this.grid[x][y].timestepAct();
									
								}
							}
						else
							for(int x =  this.grid.length-1; x >= 0; x--){
							if(this.grid[x][y] != null && !(this.grid[x][y] instanceof Wall))
							{
								this.grid[x][y].fixCoord(x,y);
								this.grid[x][y].timestepAct();
								
							}
						}
							
					}
				}
			}
			finally{
				this.lock.unlock();
				this.FSPanel.repaint();	
				Thread.sleep(10);
			}
		}
		catch(InterruptedException e){
			e.printStackTrace();
		}
		}
	}
}
