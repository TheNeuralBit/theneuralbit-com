import java.awt.Color;
import java.awt.Graphics;


/**
 * Base class of all the substances in this program.
 *
 * @author Michael Hein.
 *         Created Oct 18, 2007.
 */
public abstract class Substance {
	/**
	 * The weight of each particle of the substance.
	 */
	protected int density=0;
	/**
	 * x coordinate of particle.
	 */
	protected int x=0;
	/**
	 * y coordinate of particle.
	 */
	protected int y=0;
	/**
	 * The screen grid. 
	 */
	protected Substance[][] grid;
	/**
	 * Whether particle is on screen.
	 */
	protected boolean exists = false;
	/**
	 * Particle's Color.
	 */
	protected Color color = Color.green;
	/**
	 * Particle's Flammability.
	 */
	protected int flammability = 0;
	/**
	 * Constructor with basic x, y coordinates, plus a grid.
	 *
	 * @param X
	 * @param Y
	 * @param Grid
	 */
	public Substance(int X, int Y, Substance[][] Grid)
	{
		this.x=X;
		this.y=Y;
		this.grid = Grid;
		this.grid[this.x][this.y] = this;
		this.exists = true;
	}
	/**
	 * Constructor.
	 *
	 */
	public Substance()
	{
		super();
	}
	/**
	 * What particles of this substance do during a timestep
	 *
	 */
	public void timestepAct()
	{
		if(!this.exists) return;
		if(this.y==0)
		{
			this.delete();
		}
		else if(this.grid[this.x][this.y-1] == null)
		{
			this.grid[this.x][this.y] = null;
			this.grid[this.x][this.y-1] = this;
			this.y-=1;
		}
	}
	/**
	 * Get substance density
	 *
	 * @return the density
	 */
	public int getDensity()
	{
		return this.density;
	}
	/**
	 * Delete this particle.
	 *
	 */
	public void delete()
	{
		if(this.x > this.grid.length-1 || this.y > this.grid[0].length-1) return;
		this.exists = false;
		if(this.x > this.grid.length-1 || this.y > this.grid[0].length-1) return;
		this.grid[this.x][this.y] = null;
		
	}
	/**
	 * Draws a particle.
	 *
	 * @param g
	 */
	public void draw(Graphics g)
	{
		g.setColor(this.color);
		g.drawRect(this.x, this.y, 0, 0);
	}
	/**
	 * Fix Partcle Coordnates. DELETE before turn in, should not be necessary.
	 *
	 * @param a
	 * @param b
	 */
	public void fixCoord(int a,int b)
	{
		this.x=a;
		this.y=b;
		this.grid[this.x][this.y] = this;
	}
	/**
	 * returns whether or not this Substance's x and y position are actually on the grid.
	 *
	 * @param X
	 * @param Y
	 */
	protected boolean isOnGrid(int X, int Y)
	{
		if(X >= this.grid.length || X < 0) return false;
		else if(Y >= this.grid[1].length || Y < 0) return false;
		else return true;
	}
	/**
	 * Handles particle reactions.
	 *
	 * @param sub other substance to react with
	 */
	protected void react(Substance sub)
	{
		if(this instanceof Salt && sub instanceof Water)
		{
			Water wat = (Water)sub;
			if(wat.isSaturated()) return;
			wat.makeSalty();
			this.grid[this.x][this.y] = null;
			this.delete();	
		}
		else if(this instanceof Water && sub instanceof Salt)
		{
			Water wat = (Water)this;
			if(wat.isSaturated()) return;
			wat.makeSalty();
			this.grid[sub.x][sub.y] = null;
			sub.delete();	
		}
		else if(this instanceof Water && sub instanceof Water && (((Water)this).Salt() > 2 || ((Water)this).Salt() > 2))
		{
			Water wat1 = (Water)this;
			Water wat2 = (Water)sub;
			if(wat1.isDillutable() && wat2.Salt() < wat1.Salt()-1)
			{
				wat1.Dillute();
				wat2.makeSalty();
			}
			if(wat2.isDillutable() && wat1.Salt() < wat2.Salt()-1)
			{
				wat2.Dillute();
				wat1.makeSalty();
			}	
		}
		else if(this instanceof Water && sub instanceof Sodium)
		{
			Water wat = (Water)this;
			Sodium sod = (Sodium)sub;
			wat.delete();
			sod.burn();
		}
		else if(sub instanceof Water && this instanceof Sodium)
		{
			Water wat = (Water)sub;
			Sodium sod = (Sodium)this;
			wat.delete();
			sod.burn();
		}
		else if(sub instanceof Fire)
		{
			Fire f = (Fire)sub;
			this.reactWithFire(f);
		}
		else if(this instanceof Fire)
		{
			Fire f = (Fire)this;
			sub.reactWithFire(f);
		}
	}
	
	/**
	 * Checks whether or not something should burn.
	 *
	 * @param f a reference to the Fire object which does the burning
	 */
	public void reactWithFire(Fire f)
	{
		if(this.flammability < 0 && f.isExtinguishable())
		{
			f.delete();
		}
		else if(this.flammability > 0)
		{
			if(f.isExtinguishable() && this instanceof Sodium) return;
			this.burn();
		}
	}
	
	/** Handles how an object burns. */
	public abstract void burn();
	@Override
	public String toString()
	{
		return "Substance "+this.density;
	}
}