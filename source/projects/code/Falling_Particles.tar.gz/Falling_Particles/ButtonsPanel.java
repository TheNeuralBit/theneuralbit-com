import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSlider;
import javax.swing.SwingConstants;


/**
 * The control panel for the falling sand game.  Contains controls for what 
 * type of particle will be created, and possibly how large a space will be filled.
 *
 * @author Brian Hulette.
 *         Created Oct 19, 2007.
 */
public class ButtonsPanel extends JPanel{
	
	private String selected; 
	private JSlider slider;
	
	/** Creates a new ButtonsPanel */
	public ButtonsPanel(){
		this.setLayout(new GridLayout(4,3));
		this.selected = "WALL";
		
		ButtonGroup BG = new ButtonGroup();
		
		JRadioButton wallButton = new JRadioButton("Wall");
		wallButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				ButtonsPanel.this.selected = "WALL";
			}
		});
		BG.add(wallButton);
		this.add(wallButton);
		
		JRadioButton woodButton = new JRadioButton("Wood");
		woodButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				ButtonsPanel.this.selected = "WOOD";
			}
		});
		BG.add(woodButton);
		this.add(woodButton);
		
		JRadioButton waterButton = new JRadioButton("Water");
		waterButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				ButtonsPanel.this.selected = "WATER";
			}
		});
		BG.add(waterButton);
		this.add(waterButton);
		
		JRadioButton oilButton = new JRadioButton("Oil");
		oilButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				ButtonsPanel.this.selected = "OIL";
			}
		});
		BG.add(oilButton);
		this.add(oilButton);
		
		JRadioButton sandButton = new JRadioButton("Sand");
		sandButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				ButtonsPanel.this.selected = "SAND";
			}
		});
		BG.add(sandButton);
		this.add(sandButton);
		
		JRadioButton saltButton = new JRadioButton("Salt");
		saltButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				ButtonsPanel.this.selected = "SALT";
			}
		});
		BG.add(saltButton);
		this.add(saltButton);
		
		JRadioButton fireButton = new JRadioButton("Fire");
		fireButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				ButtonsPanel.this.selected = "FIRE";
			}
		});
		BG.add(fireButton);
		this.add(fireButton);
		
		JRadioButton emberButton = new JRadioButton("Embers");
		emberButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				ButtonsPanel.this.selected = "EMBERS";
			}
		});
		BG.add(emberButton);
		this.add(emberButton);
		
		JRadioButton soduimButton = new JRadioButton("Sodium");
		soduimButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				ButtonsPanel.this.selected = "SODIUM";
			}
		});
		BG.add(soduimButton);
		this.add(soduimButton);
		
		JRadioButton eraseButton = new JRadioButton("Erase");
		eraseButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				ButtonsPanel.this.selected = "ERASE";
			}
		});
		BG.add(eraseButton);
		this.add(eraseButton);		
		
		this.slider = new JSlider(SwingConstants.HORIZONTAL, 0,16,1);
		this.slider.setMajorTickSpacing(4);
		this.slider.setMinorTickSpacing(1);
		this.slider.setSnapToTicks(true);
		this.slider.setPaintTicks(true);
		this.slider.setPaintLabels(true);
		
		this.add(this.slider);
			
		this.repaint();
	}
	/** @return the radius selected by the slider */
	protected int getRadius(){
		return this.slider.getValue();
	}
	/** @return the Substance selected by the radio buttons */
	protected String getSelected(){
		return this.selected;
	}
}
