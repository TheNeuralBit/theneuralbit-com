import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Random;

import javax.swing.JPanel;


/**
 * TODO Put here a description of what this class does.
 *
 * @author Brian Hulette.
 *         Created Oct 19, 2007.
 */
public class FallingSandPanel extends JPanel implements MouseListener , MouseMotionListener{
	
	private Substance[][] grid;
	private ButtonsPanel BPanel;
	
	private Point lastPoint;
	
	/**
	 * Creates the panel which draws the particles;
	 *
	 * @param grid
	 */
	public FallingSandPanel(Substance[][] grid, ButtonsPanel BPanel){
		this.setBackground(Color.darkGray);
		this.grid = grid;
		this.BPanel = BPanel;
		
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		for(Substance[] l : this.grid){
			for(Substance s : l){
				if(s!=null)
					s.draw(g);
			}
		}
	}
	public void mouseClicked(MouseEvent e)
	{		
		int xPos = e.getX();
		int yPos = e.getY();
		
		this.lastPoint = new Point(e.getX(), e.getY());
		
		CreateSubstance(xPos,yPos, BPanel.getRadius());
		this.repaint();
	}
	
	public void mouseReleased(MouseEvent e){
		this.lastPoint = null;
	}
	
	public void mouseDragged(MouseEvent e) {
		
		int xPos = e.getX();
		int yPos = e.getY();
				
		if(this.lastPoint == null || ( this.lastPoint.x == xPos && this.lastPoint.y == yPos ))
			CreateSubstance(xPos, yPos, this.BPanel.getRadius());
		
		interpolate(this.lastPoint, new Point(xPos, yPos), this.BPanel.getRadius());
		this.lastPoint = new Point(e.getX(), e.getY());
	}
	
	public void mousePressed(MouseEvent e){
		this.lastPoint = new Point(e.getX(), e.getY());
	}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mouseMoved(MouseEvent e){}
	
	private void interpolate(Point p1, Point p2, int radius){		
		
		// if p1 is to the left of p2, switch places
		if(p1.x > p2.x){
			interpolate(p2, p1, radius);
			return;
		}
		
		// Base case:
		// if points are adjacent, return.
		if((p1.x + 1 == p2.x && (p1.y == p2.y || p1.y + 1 == p2.y || p1.y - 1 == p2.y)) ||
		   (p1.x - 1 == p2.x && (p1.y == p2.y || p1.y + 1 == p2.y || p1.y - 1 == p2.y)) ||
		   (p1.x == p2.x && (p1.y == p2.y || p1.y + 1 == p2.y || p1.y - 1 == p2.y)))
			return;
		
		if(p2.x == p1.x){
			if(p2.y > p1.y){
				CreateSubstance(p1.x, p1.y + 1, radius);
				interpolate(new Point(p1.x, p1.y+1), p2, radius);
			}
			else{
				CreateSubstance(p1.x, p1.y - 1, radius);
				interpolate(new Point(p1.x, p1.y - 1), p2, radius);
			}
			return;
		}
		
		double slope = (p2.y-p1.y)/(p2.x-p1.x);
		
		// if p2 is approximately to the right
		if(slope <= 0.414 && slope >= -0.414){
			CreateSubstance(p1.x + 1, p1.y, radius);
			interpolate(new Point(p1.x + 1, p1.y), p2, radius);
			return;
		}
		// if p2 is approximately up to the right
		else if(slope <= 2.41 && slope > 0.414){
			CreateSubstance(p1.x + 1, p1.y + 1, radius);
			interpolate(new Point(p1.x + 1, p1.y + 1), p2, radius);
			return;
		}
		// is p2 is down to the right
		else if(slope < -0.414 && slope >= -2.41){
			CreateSubstance(p1.x - 1, p1.y - 1, radius);
			interpolate(new Point(p1.x - 1, p1.y - 1), p2, radius);
			return;
		}
		// if p2 is approximately up
		else if(slope > 0){
			CreateSubstance(p1.x, p1.y + 1, radius);
			interpolate(new Point(p1.x, p1.y + 1), p2, radius);
			return;
		}
		// if p2 is approximately down
		else{
			CreateSubstance(p1.x, p1.y - 1, radius);
			interpolate(new Point(p1.x, p1.y - 1), p2, radius);
			return;
		}
	}
	
	private void CreateSubstance(int x1, int y1, int radius){
		String selected = this.BPanel.getSelected();
		if(selected.equals("WALL"))
			CreateSomeWall(x1, y1, radius);
		else if(selected.equals("WATER"))
			CreateSomeWater(x1, y1, radius);
		else if(selected.equals("SAND"))
			CreateSomeSand(x1, y1, radius);
		else if(selected.equals("SALT"))
			CreateSomeSalt(x1, y1, radius);
		else if(selected.equals("OIL"))
			CreateSomeOil(x1, y1, radius);
		else if(selected.equals("FIRE"))
			CreateSomeFire(x1, y1, radius);
		else if(selected.equals("WOOD"))
			CreateSomeWood(x1, y1, radius);
		else if(selected.equals("EMBERS"))
			CreateSomeEmbers(x1, y1, radius);
		else if(selected.equals("SODIUM"))
			CreateSomeSodium(x1, y1, radius);
		else if(selected.equals("ERASE"))
			erase(x1, y1, radius);
		this.repaint();
	}
	
	// creates a square of wall with side length 2*radius centered at (x,y)
	private void CreateSomeWall(int x1, int y1, int radius)
	{
		for(int i=x1-radius; i<=x1+radius;++i)
		{
			for(int j=y1-radius; j<=y1+radius;++j)
			{
				if(isOnMap(i,j)) this.grid[i][j] = new Wall(i,j,this.grid);
			}
		}
	}
	
	// creates a square of sand with side length 2*radius centered at (x,y)
	// at each grid position theres a random chance no sand will be put there.
	private void CreateSomeSand(int x1, int y1, int radius)
	{
		Random rand = new Random();
		for(int i=x1-radius; i<=x1+radius;++i)
		{
			for(int j=y1-radius; j<=y1+radius;++j)
			{
				if(isOnMap(i,j) && rand.nextInt(3)==0) this.grid[i][j] = new Sand(i,j,this.grid);
			}
		}
	}
	
	// creates a square of sand with side length 2*radius centered at (x,y)
	// at each grid position theres a random chance no sand will be put there.
	private void CreateSomeWater(int x1, int y1, int radius)
	{
		Random rand = new Random();
		for(int i=x1-radius; i<=x1+radius;++i)
		{
			for(int j=y1-radius; j<=y1+radius;++j)
			{
				if(isOnMap(i,j)&& rand.nextInt(3)==0) this.grid[i][j] = new Water(i,j,this.grid);
			}
		}
	}
	private void CreateSomeSalt(int x1, int y1, int radius)
	{
		Random rand = new Random();
		for(int i=x1-radius; i<=x1+radius;++i)
		{
			for(int j=y1-radius; j<=y1+radius;++j)
			{
				if(isOnMap(i,j) && rand.nextInt(3)==0) this.grid[i][j] = new Salt(i,j,this.grid);
			}
		}
	}
	private void CreateSomeOil(int x1, int y1, int radius)
	{
		Random rand = new Random();
		for(int i=x1-radius; i<=x1+radius;++i)
		{
			for(int j=y1-radius; j<=y1+radius;++j)
			{
				if(isOnMap(i,j) && rand.nextInt(3)==0) this.grid[i][j] = new Oil(i,j,this.grid);
			}
		}
	}
	private void CreateSomeFire(int x1, int y1, int radius)
	{
		Random rand = new Random();
		for(int i=x1-radius; i<=x1+radius;++i)
		{
			for(int j=y1-radius; j<=y1+radius;++j)
			{
				if(isOnMap(i,j) && rand.nextInt(3)==0) this.grid[i][j] = new Fire(i,j,this.grid);
			}
		}
	}
	private void CreateSomeWood(int x1, int y1, int radius)
	{
		for(int i=x1-radius; i<=x1+radius;++i)
		{
			for(int j=y1-radius; j<=y1+radius;++j)
			{
				if(isOnMap(i,j)) this.grid[i][j] = new Wood(i,j,this.grid);
			}
		}
	}
	private void CreateSomeEmbers(int x1, int y1, int radius)
	{
		for(int i=x1-radius; i<=x1+radius;++i)
		{
			for(int j=y1-radius; j<=y1+radius;++j)
			{
				if(isOnMap(i,j)) this.grid[i][j] = new Ember(i,j,this.grid);
			}
		}
	}
	private void CreateSomeSodium(int x1, int y1, int radius)
	{
		Random rand = new Random();
		for(int i=x1-radius; i<=x1+radius;++i)
		{
			for(int j=y1-radius; j<=y1+radius;++j)
			{
				if(isOnMap(i,j) && rand.nextInt(3)==0) this.grid[i][j] = new Sodium(i,j,this.grid);
			}
		}
	}
	private void erase(int x1, int y1, int radius)
	{
		for(int i=x1-radius; i<=x1+radius;++i)
		{
			for(int j=y1-radius; j<=y1+radius;++j)
			{
				if(isOnMap(i,j)) this.grid[i][j] = null;
			}
		}
	}
	private boolean isOnMap(int x, int y)
	{
		if(x >= 0 && y >= 0 && x < this.grid.length && y < this.grid[0].length) return true;
		else return false;
	}
}