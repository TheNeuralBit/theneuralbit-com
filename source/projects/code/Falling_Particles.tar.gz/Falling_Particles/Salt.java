import java.awt.Color;
import java.util.Random;


/**
 * TODO Put here a description of what this class does.
 *
 * @author Michael Hein.
 *         Created Oct 25, 2007.
 */
public class Salt extends Solid {
	/**
	 * Constructor.
	 *
	 * @param X
	 * @param Y
	 * @param Grid
	 */
	public Salt(int X, int Y, Substance[][] Grid)
	{
		super(X,Y,Grid);
		Random rand = new Random();
		this.density = 14;
		this.flammability = 0;
		this.color = new Color(rand.nextInt(12)+243,rand.nextInt(12)+243,rand.nextInt(12)+243);
	}
	@Override
	public String toString()
	{
		return "Salt "+this.density;
	}
}
