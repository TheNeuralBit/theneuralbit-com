import java.awt.Color;
import java.util.Random;


/**
 * TODO Put here a description of what this class does.
 *
 * @author Michael Hein.
 *         Created Oct 28, 2007.
 */
public class Ember extends Fire {
	/**
	* Constructor.
	 *
	 * @param X
	 * @param Y
	 * @param Grid
	 */
	public Ember(int X, int Y, Substance[][] Grid)
	{
		super(X,Y,Grid);
		Random rand = new Random();
		this.density = 9999;
		this.flammability = 0;
		if(rand.nextInt(3) == 1)
			this.color = new Color(150+rand.nextInt(25),10+rand.nextInt(25),0);
		else 
		{
			int hold = rand.nextInt(25);
			this.color = new Color(hold,hold,hold);
		}

	}
	@Override
	public void timestepAct()
	{
		Random rand = new Random();
		/*for(int a=-1; a<1;++a)
		{
			for(int b=-1; b<1;++b)
			{
				if(this.x+a >= 0 && this.y+b>=0 && this.x+a < this.grid.length && this.y+b < this.grid[6].length)
					if(this.grid[this.x+a][this.y+b] !=null && this.x+a > 0 && this.y+b > 0)this.react(this.grid[this.x+a][this.y+b]);
			}
		}*/
		if(this.y>=this.grid[0].length-1)
		{ // if it hit bottom, delete
			this.delete();
		}
		if(rand.nextInt(30)==1)
		{
			if(rand.nextInt(3) == 1)
				this.color = new Color(150+rand.nextInt(25),10+rand.nextInt(25),0);
			else 
			{
				int hold = rand.nextInt(25);
				this.color = new Color(hold,hold,hold);
			}
		}
		if(this.grid[this.x][this.y-1] == null && rand.nextInt(10)==1)
		{
			new Fire(this.x, this.y-1, this.grid);
		}
	}
	@Override
	public void burn(){}
	@Override
	public String toString()
	{
		return "Ember "+this.density;
	}
}
