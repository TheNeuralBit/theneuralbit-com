import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JFrame;


/**
 * TODO Put here a description of what this class does.
 *
 * @author Brian Hulette.
 *         Created Oct 19, 2007.
 */
public class FallingSandFrame extends JFrame{
		
	/**
	 * Creates a FallingSandFrame which contains the FallingSandPanel and
	 * ButtonsPanel
	 *
	 * @param width
	 * @param height
	 */
	public FallingSandFrame( int width, int height){
		this.setTitle("Falling Sand");
		this.setLayout(new GridBagLayout());
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(width, height);
		
		Substance[][] grid = new Substance[width][2*height/3];
		
		ButtonsPanel BPanel = new ButtonsPanel();
		FallingSandPanel FSPanel = new FallingSandPanel(grid, BPanel);
		
		GridBagConstraints c = new GridBagConstraints();
		c.anchor = GridBagConstraints.CENTER;
		
		c.weighty = 1.0;
		c.weightx = 0.5;
		c.gridx = 0;
		c.gridy = 0;
		c.gridheight = 2;
		c.fill = GridBagConstraints.BOTH;
		this.add(FSPanel,c);
				
		c.weighty = 0.1;
		c.weightx = 0.5;
		c.gridy = 2;
		c.gridheight = 1;
		this.add(BPanel,c);
		
		//start moving particles
		(new SubstanceMover(grid, FSPanel)).start();
		
		this.setVisible(true);
	}
}
