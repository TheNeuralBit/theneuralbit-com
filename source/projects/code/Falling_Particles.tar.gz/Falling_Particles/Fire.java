import java.awt.Color;
import java.util.Random;


/**
 * TODO Put here a description of what this class does.
 *
 * @author Michael Hein.
 *         Created Oct 26, 2007.
 */
public class Fire extends Substance {
	/** How many more iterations the fire stays alive */
	protected int life=0;
	protected boolean extinguishable = true;
	/**
	* Constructor.
	 *
	 * @param X
	 * @param Y
	 * @param Grid
	 */
	public Fire(int X, int Y, Substance[][] Grid)
	{
		super(X,Y,Grid);
		Random rand = new Random();
		this.density = 9999;
		this.life = rand.nextInt(12);
		this.flammability = 0;
		this.color = new Color(150+rand.nextInt(25),10+rand.nextInt(25),0);
	}
	@Override
	public void timestepAct()
	{
/*		for(int a=-1; a<1;++a)
		{
			for(int b=-1; b<1;++b)
			{
				if(this.x+a >= 0 && this.y+b>=0 && this.x+a < this.grid.length && this.y+b < this.grid[6].length)
					if(this.grid[this.x+a][this.y+b] !=null && this.x+a > 0 && this.y+b > 0)this.react(this.grid[this.x+a][this.y+b]);
			}
		}*/
		if(this.y>=this.grid[0].length-1)
		{ // if it hit bottom, delete
			this.delete();
		}
		this.life--;
		if(this.life <= 0)
		{
			this.delete();
		}
		else
		{
			Random rand = new Random();
			if(this.grid[this.x][this.y-1] == null && rand.nextInt(6) ==1)
			{
				new Fire(this.x, this.y-1, this.grid);
			}
		}
	}
	public void disableExtinguishable()
	{
		this.extinguishable = false;
	}
	public boolean isExtinguishable()
	{
		return this.extinguishable;
	}
	@Override
	public void burn(){}
	@Override
	public String toString()
	{
		return "Fire "+this.density;
	}
}