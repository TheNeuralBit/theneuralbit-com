import java.awt.Color;
import java.util.Random;


/**
 * TODO Put here a description of what this class does.
 *
 * @author Michael Hein.
 *         Created Oct 19, 2007.
 */
public class Sand extends Solid {
	/**
	 * Constructor.
	 *
	 * @param X
	 * @param Y
	 * @param Grid
	 */
	public Sand(int X, int Y, Substance[][] Grid)
	{
		super(X,Y,Grid);
		Random rand = new Random();
		this.density = 16;
		this.flammability = 0;
		this.color = new Color(rand.nextInt(25)+210,rand.nextInt(25)+210,rand.nextInt(25)+10);
	}
	public String toString()
	{
		return "Sand "+this.density;
	}
}
