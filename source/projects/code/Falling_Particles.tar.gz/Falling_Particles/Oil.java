import java.awt.Color;
import java.util.Random;


/**
 * TODO Put here a description of what this class does.
 *
 * @author Michael Hein.
 *         Created Oct 26, 2007.
 */
public class Oil extends Liquid {
	/**
	 * Constructor.
	 *
	 * @param X
	 * @param Y
	 * @param Grid
	 */
	public Oil(int X, int Y, Substance[][] Grid)
	{
		super(X,Y,Grid);
		this.density = 7;
		this.flammability = 1;
		this.color = new Color(15,10,15);
	}
	@Override
	public void burn()
	{
		Random rand = new Random();
		if(rand.nextInt(2) == 1) return;
		Fire f = new Fire(this.x, this.y, this.grid);
		this.grid[this.x][this.y] = f;
		for(int a=1; a>=-1;--a)
		{
			for(int b=-1; b<=1;++b)
			{
				if(a!=0 || b!=0)
					if(f.x+a >= 0 && f.y+b>=0 && f.x+a < f.grid.length && f.y+b < f.grid[6].length)
						if(f.grid[f.x+a][f.y+b] !=null && f.x+a > 0 && f.y+b > 0)
						{
							f.react(this.grid[f.x+a][f.y+b]);
							return;
						}
			}
		}
		//this.delete();
	}
	public String toString()
	{
		return "Oil "+this.density;
	}
}
