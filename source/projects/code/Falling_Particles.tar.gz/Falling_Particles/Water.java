import java.awt.Color;


/**
 * Water.
 *
 * @author Michael Hein.
 *         Created Oct 19, 2007.
 */
public class Water extends Liquid {
	private int salty = 0;
	/**
	 * TODO Put here a description of what this constructor does.
	 *
	 * @param X
	 * @param Y
	 * @param Grid
	 */
	public Water(int X, int Y, Substance[][] Grid)
	{
		super(X,Y,Grid);
		this.density = 10;
		this.color = Color.blue;
		this.flammability = -1;
	}
	/**
	 * Checks if water particle is salty
	 *
	 * @return true if salty, otherwise false
	 */
	public boolean isSaturated()
	{
		if(this.salty > 2) return true;
		else return false;
	}
	public boolean isDillutable()
	{
		if(this.salty > 1) return true;
		else return false;
	}
	public int Salt()
	{
		return this.salty;
	}
	/**
	 * Makes the water particle salty.
	 *
	 */
	public void makeSalty()
	{
		if(this.salty > 2) return;
		this.salty++;
		this.color = new Color(0,35*this.salty, 200);
		this.density++;
	}
	public void Dillute()
	{
		if(this.salty < 2) return;
		this.salty--;
		this.color = new Color(0,35*this.salty, 200);
		this.density--;
	}
	@Override
	public String toString()
	{
		return "Water "+this.density;
	}
}
